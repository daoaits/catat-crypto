import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// the translations
// (tip move them in a JSON file and import them,
// or even better, manage them separated from your code: https://react.i18next.com/guides/multiple-translation-files)
const resources = {
  en: {
    translation: {
      nav: {
        home: "Home",
        features: "Features",
        contact: "Contact",
        about: "About Us",
        login: "Login",
        getStarted: "Get Started"
      },
      hero: {
        badge: "Revolutionizing Crypto Analytics",
        title: "The Opportunity is You",
        subtitle: "Track, analyze, and master your crypto trading journey. Take control of your portfolio with precision data and intuitive journaling.",
        startBtn: "Get Started — It's Free",
        demoBtn: "Watch Demo"
      },
      stats: {
        activeTraders: "Traders",
        volumeTracked: "Trades Logged",
        toStart: "To Start",
        trustedBy: "Trusted By Traders",
        across: "Across Indonesia 🇮🇩",
        join: "Join 2k+ smart traders"
      },
      bento: {
        institutional: "Institutional Dashboard",
        master: "Master Your Trading Edge",
        masterDesc: "Our advanced logging engine tracks every metric from psychological state to slippage, helping you identify what truly drives your profits.",
        weekly: "Weekly Performance",
        community: "Community Wisdom",
        communityDesc: "Access anonymized trade data from 2,000+ top traders in Indonesia to see where the market is moving.",
        explore: "Explore Insights",
        accurate: "Accurate PnL &\nReconciliation",
        accurateDesc: "Achieve 99.9% trade matching accuracy in under 3 seconds with real-time sync, multi-exchange aggregation, and instant error detection.",
        security: "Security (API Safety)",
        securityDesc: "Secure Encryption (AES-256 + End-to-End) — Your API keys are encrypted both in transit and at rest.",
        points: {
          readonly: "Read-Only API Access Only",
          nocustody: "No Custody",
          secure: "Secure Key Storage",
          privacy: "Privacy First",
          soc2: "SOC 2 / ISO 27001 Ready"
        }
      },
      partners: {
        trustedBy: "INTEGRATION WITH"
      },
      features: {
        badge: "POWERFUL FEATURES",
        title: "Everything you need to master your trades",
        subtitle: "Comprehensive tools designed to give you an unfair advantage in the crypto markets.",
        journal: {
           title: "Trading Journal",
           desc: "Automatically import trades, add tags, and track your performance with precision."
        },
        analytics: {
            title: "Advanced Analytics",
            desc: "Understand your strengths and weaknesses with our deep-dive performance metrics."
        },
        portfolio: {
            title: "Portfolio Tracker",
            desc: "Monitor your multi-exchange balances and live PnL in one unified dashboard."
        }
      },
      comparison: {
        badge: "Performance Analytics",
        title: "The Cost of Blind Trading",
        subtitle: "Stop leaving your capital to chance. Compare the manual chaos against automated precision.",
        without: "WITHOUT CATAT CRYPTO",
        with: "WITH CATAT CRYPTO",
        tradeAccuracy: "Trade Accuracy",
        emotionalImpact: "Emotional Impact",
        high: "High",
        low: "Low",
        inconsistent: "Inconsistent Performance",
        reactionary: "Reactionary Decision Making",
        datadriven: "Data-Driven Precision",
        systematic: "Systematic Execution",
        bridge: "Bridge the Gap Today"
      },
      integration: {
        badge: "SEAMLESS INTEGRATION",
        title: "Connect to your favorite exchanges",
        subtitle: "Automatically sync your trade history and balances via secure read-only API connections.",
        connectBtn: "Connect Exchange",
        viewAllBtn: "View All Integrations",
        supported: "SUPPORTED",
        exchanges: "EXCHANGES"
      },
      appMockup: {
        badge: "Everything You Need",
        title: "One App. Total Control\nOver Your Crypto Trades.",
        desc: "Experience a unified workspace designed for serious traders. Track portfolios, analyze risk, and leverage AI insights without leaving the terminal.",
        tabs: {
          dashboard: "Dashboard",
          reports: "Reports",
          calendar: "Calendar",
          trades: "Trades",
          notebook: "Notebook",
          ai: "AI Assistant"
        },
        accountBal: "Account Balance",
        liveIntel: "Live Intelligence",
        advAnalytics: "Advanced Analytics Screen"
      },
      hub: {
        badge: "Catat Crypto Hub",
        title: "Supported Brokers",
        desc: "Connect your favorite crypto exchange and start tracking your trades\nautomatically with enterprise-grade node precision.",
        missingUrl: "Don't see your broker? More integrations coming soon."
      },
      pricing: {
        title: "Choose Your Plan",
        desc: "Scale your tracking as you scale your profits.",
        free: "Free",
        freeDesc: "Basic Tracking",
        freeBtn: "Start Free",
        freeLimit: "2 Weeks Free Trial of Pro Package",
        pro: "PRO",
        proBadge: "Most Popular",
        proDesc: "For Active Traders",
        proBtn: "Get Pro Access",
        monthly: "Monthly",
        yearly: "Yearly",
        save: "Save 15%",
        premium: "Premium",
        premiumDesc: "For Advance Traders",
        premiumBtn: "Get Premium Access",
        features: {
          auto: "Auto-Sync API",
          multi: "Multi-Variable Analytics",
          cal: "Calendar Daily Journal",
          port: "Portfolio Analytics",
          add: "Add Manually Your Trades"
        }
      },
      about: {
        badge: "ABOUT US",
        title: "Built by traders, for traders.",
        subtitle: "We experienced the pain of tracking hundreds of trades across multiple exchanges using manual spreadsheets.",
        mission: "Our Mission",
        missionDesc: "To provide the most comprehensive, easy-to-use, and secure platform for traders to track, analyze, and optimize their crypto portfolios.",
        vision: "Our Vision",
        visionDesc: "To become the global standard for crypto trading journals and portfolio analytics."
      },
      contact: {
        badge: "Contact Us",
        title: "We're here to help.",
        subtitle: "Have questions about integration, pricing, or features? Reach out to our team.",
        realTime: "Real-Time Live Chat",
        realTimeDesc: "Get answers in minutes from real human support agents for account setup, API, and portfolio data analysis.",
        avgResponse: "Average response < 2 minutes",
        multilingual: "24/7 multilingual support",
        startChatBtn: "Start Chat Now",
        helpCenter: "Help Center",
        helpCenterDesc: "Comprehensive documentation and video tutorials to assist you.",
        learnMore: "Learn More",
        discord: "Discord Community",
        discordDesc: "Join thousands of traders and our development team.",
        joinNow: "Join Now",
        chat: {
            assistant: "Assistant Active",
            today: "TODAY",
            greeting: "Hello! I'm your CryptoJournal AI. How can I help you manage your digital portfolio or support tickets today?",
            setup: "Setup Portfolio",
            ticket: "Support Ticket",
            placeholder: "How can we help?",
            emailPlaceholder: "Email Address",
            poweredBy: "Powered by Catat Crypto Support Engine"
        }
      },
      footer: {
        desc: "The ultimate crypto trading journal and portfolio management platform.",
        product: "Product",
        company: "Company",
        legal: "Legal",
        rights: "© 2026 Catat Crypto. All rights reserved."
      },
      partnership: {
        badge: "PARTNERSHIP",
        title: "Earn While You Create.\nPartner Program — ",
        soon: "Coming Soon.",
        f1: "Up to 35% Recurring Commission",
        f2: "Exclusive Partner Verification Badge",
        f3: "Be Featured on Official Socials",
        btn: "Join the Waitlist",
        payout: "Estimated Payout"
      },
      cta: {
        title1: "Your Next Trade Could Be\n",
        title2: "Your Best Trade.",
        desc: "Start journaling today and discover what's really driving your results. Join thousands of traders who have turned their performance around with precision data.",
        btn1: "Get Started — It's Free",
        btn2: "Watch Demo",
        f1: "No Credit Card Required",
        f2: "Free Plan Available",
        f3: "Setup in under 5 minutes"
      }
    }
  },
  id: {
    translation: {
      nav: {
        home: "Beranda",
        features: "Fitur",
        contact: "Kontak",
        about: "Tentang",
        login: "Masuk",
        getStarted: "Mulai"
      },
      hero: {
        badge: "MEREVOLUSI ANALITIK KRIPTO",
        title: "Peluang Ada Pada Anda",
        subtitle: "Lacak, analisis, dan kuasai perjalanan trading kripto Anda. Ambil kendali portofolio Anda dengan data presisi dan jurnal yang intuitif.",
        startBtn: "Mulai Secara Gratis",
        demoBtn: "Tonton Demo"
      },
      stats: {
        activeTraders: "Trader Aktif",
        volumeTracked: "Volume Terlacak",
        toStart: "Untuk Memulai",
        trustedBy: "Dipercaya Oleh Trader",
        across: "Di Seluruh Indonesia 🇮🇩",
        join: "Gabung 2k+ trader cerdas"
      },
      bento: {
        institutional: "Dasbor Institusional",
        master: "Kuasai Keunggulan Trading",
        masterDesc: "Mesin pencatatan canggih kami melacak setiap metrik dari aspek psikologis hingga slip harga, membantu Anda mengidentifikasi apa yang benar-benar mendorong profit Anda.",
        weekly: "Performa Mingguan",
        community: "Kebijaksanaan Komunitas",
        communityDesc: "Akses data perdagangan anonim dari 2.000+ trader teratas di Indonesia untuk melihat ke mana arah pasar bergerak.",
        explore: "Eksplorasi Wawasan",
        accurate: "PnL & Rekonsiliasi\nAkurat",
        accurateDesc: "Capai akurasi pencocokan 99.9% dalam waktu kurang dari 3 detik secara real-time, agregasi berbagai bursa, dan deteksi error.",
        security: "Keamanan (API Safety)",
        securityDesc: "Enkripsi Aman (AES-256 + End-to-End) — Kunci API Anda dienkripsi baik secara transit maupun diam.",
        points: {
          readonly: "Akses API Hanya Baca",
          nocustody: "Tanpa Penyimpanan Dana",
          secure: "Penyimpanan Kunci Aman",
          privacy: "Privasi Utama",
          soc2: "SOC 2 / Standar ISO 27001"
        }
      },
      partners: {
        trustedBy: "INTEGRASI DENGAN"
      },
      features: {
        badge: "FITUR ANDAL",
        title: "Semua yang Anda butuhkan untuk menguasai trading",
        subtitle: "Alat komprehensif yang dirancang untuk memberi Anda keuntungan nyata di pasar kripto.",
        journal: {
           title: "Jurnal Trading",
           desc: "Impor riwayat transaksi secara otomatis, tambahkan tag, dan pantau performa Anda dengan akurat."
        },
        analytics: {
            title: "Analitik Lanjutan",
            desc: "Pahami kekuatan dan kelemahan Anda dengan metrik performa mendalam kami."
        },
        portfolio: {
            title: "Papan Portofolio",
            desc: "Pantau saldo berbagai bursa dan PnL real-time dalam satu dasbor terpadu."
        }
      },
      comparison: {
        badge: "Analisis Performa",
        title: "Biaya Trading Tanpa Arah",
        subtitle: "Jangan biarkan modal Anda bergantung pada keberuntungan. Bandingkan kekacauan manual dengan presisi otomatis.",
        without: "TANPA CATAT CRYPTO",
        with: "DENGAN CATAT CRYPTO",
        tradeAccuracy: "Akurasi Trading",
        emotionalImpact: "Dampak Emosional",
        high: "Tinggi",
        low: "Rendah",
        inconsistent: "Performa Tidak Konsisten",
        reactionary: "Pengambilan Keputusan Reaktif",
        datadriven: "Presisi Berbasis Data",
        systematic: "Eksekusi Sistematis",
        bridge: "Jembatani Kesenjangan Hari Ini"
      },
      integration: {
        badge: "INTEGRASI MULUS",
        title: "Hubungkan ke bursa favorit Anda",
        subtitle: "Sinkronkan riwayat transaksi dan saldo Anda secara otomatis melalui koneksi API read-only otomatis dan aman.",
        connectBtn: "Hubungkan Bursa",
        viewAllBtn: "Lihat Semua Integrasi",
        supported: "BURSA YANG",
        exchanges: "DIDUKUNG"
      },
       appMockup: {
        badge: "Semua Yang Anda Butuhkan",
        title: "Satu Aplikasi. Kendali Penuh\nAtas Trading Kripto Anda.",
        desc: "Rasakan ruang kerja terpadu yang dirancang untuk trader serius. Lacak portofolio, analisis risiko, dan manfaatkan wawasan AI tanpa meninggalkan terminal.",
        tabs: {
          dashboard: "Dasbor",
          reports: "Laporan",
          calendar: "Kalender",
          trades: "Trading",
          notebook: "Catatan",
          ai: "Asisten AI"
        },
        accountBal: "Saldo Akun",
        liveIntel: "Kecerdasan Langsung",
        advAnalytics: "Layar Analitik Lanjutan"
      },
      hub: {
        badge: "Hub Catat Crypto",
        title: "Bursa Yang Didukung",
        desc: "Hubungkan bursa kripto favorit Anda dan mulai lacak rute perdagangan Anda\nsecara otomatis dengan presisi setingkat institusi.",
        missingUrl: "Tidak menemukan bursa Anda? Lebih banyak integrasi akan segera hadir."
      },
      pricing: {
        title: "Pilih Paket Anda",
        desc: "Tingkatkan pelacakan seiring dengan meningkatnya profit Anda.",
        free: "Gratis",
        freeDesc: "Pelacakan Dasar",
        freeBtn: "Mulai Gratis",
        freeLimit: "Uji Coba 2 Minggu Kelas Pro",
        pro: "PRO",
        proBadge: "Paling Populer",
        proDesc: "Untuk Trader Aktif",
        proBtn: "Dapatkan Akses Pro",
        monthly: "Bulanan",
        yearly: "Tahunan",
        save: "Hemat 15%",
        premium: "Premium",
        premiumDesc: "Untuk Trader Profesional",
        premiumBtn: "Dapatkan Akses Premium",
        features: {
          auto: "API Auto-Sync",
          multi: "Analitik Multi-Variabel",
          cal: "Jurnal Harian Kalender",
          port: "Analitik Portofolio",
          add: "Tambah Trading Manual"
        }
      },
      about: {
        badge: "TENTANG KAMI",
        title: "Dibuat oleh trader, untuk trader.",
        subtitle: "Kami mengalami sendiri sulitnya melacak ratusan transaksi di berbagai bursa menggunakan spreadsheet manual.",
        mission: "Misi Kami",
        missionDesc: "Menyediakan platform analitik paling komprehensif, mudah digunakan, dan aman bagi trader untuk melacak, menganalisis, dan mengoptimalkan portofolio komplit kripto mereka.",
        vision: "Visi Kami",
        visionDesc: "Menjadi standar global untuk jurnal trading kripto dan alat analisis portofolio."
      },
      contact: {
        badge: "Hubungi Kami",
        title: "Kami siap membantu.",
        subtitle: "Punya pertanyaan tentang integrasi, harga, atau fitur? Hubungi tim kami.",
        realTime: "Live Chat Real-Time",
        realTimeDesc: "Dapatkan jawaban dalam hitungan menit dari agen bantuan untuk setup akun, API, dan analisis data portofolio.",
        avgResponse: "Rata-rata respons < 2 menit",
        multilingual: "Dukungan multibahasa 24/7",
        startChatBtn: "Mulai Chat",
        helpCenter: "Pusat Bantuan",
        helpCenterDesc: "Dokumentasi komprehensif dan tutorial video untuk membantu Anda.",
        learnMore: "Pelajari",
        discord: "Komunitas Discord",
        discordDesc: "Bergabung dengan ribuan trader dan tim developer kami.",
        joinNow: "Gabung",
        chat: {
            assistant: "Asisten Aktif",
            today: "HARI INI",
            greeting: "Halo! Saya AI Catat Crypto Anda. Bagaimana saya bisa membantu mengelola portofolio digital Anda atau membuat tiket bantuan hari ini?",
            setup: "Setup Portofolio",
            ticket: "Tiket Dukungan",
            placeholder: "Ada yang bisa dibantu?",
            emailPlaceholder: "Alamat Email",
            poweredBy: "Didukung oleh Mesin Catat Crypto"
        }
      },
      footer: {
        desc: "Platform manajemen portofolio dan jurnal trading kripto terlengkap.",
        product: "Produk",
        company: "Perusahaan",
        legal: "Legal",
        rights: "© 2026 Catat Crypto. Hak Cipta Dilindungi."
      },
      partnership: {
        badge: "KEMITRAAN",
        title: "Hasilkan Sambil Berkreasi.\nProgram Mitra — ",
        soon: "Segera Hadir.",
        f1: "Komisi Berulang hingga 35%",
        f2: "Lencana Verifikasi Mitra Eksklusif",
        f3: "Ditampilkan di Media Sosial Resmi",
        btn: "Bergabung dengan Daftar Tunggu",
        payout: "Perkiraan Pembayaran"
      },
      cta: {
        title1: "Trading Anda Selanjutnya\n",
        title2: "Bisa Jadi yang Terbaik.",
        desc: "Mulai buat jurnal hari ini dan temukan apa yang sebenarnya mendorong hasil Anda. Bergabunglah dengan ribuan pedagang yang telah membalikkan kinerja mereka dengan data presisi.",
        btn1: "Mulai — Ini Gratis",
        btn2: "Tonton Demo",
        f1: "Tidak Perlu Kartu Kredit",
        f2: "Tersedia Paket Gratis",
        f3: "Pengaturan dalam waktu kurang dari 5 menit"
      }
    }
  }
};

i18n
  .use(initReactI18next) // passes i18n down to react-i18next
  .init({
    resources,
    lng: "en", // default language
    fallbackLng: "en",

    interpolation: {
      escapeValue: false // react already safes from xss
    }
  });

  export default i18n;
